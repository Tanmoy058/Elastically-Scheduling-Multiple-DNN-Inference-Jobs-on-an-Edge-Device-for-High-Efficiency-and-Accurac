import argparse
import random
import sys

def write_graph(num_devices, flops_range, memory_range, bandwidth_range, filename=None):
    old_stdout = sys.stdout
    if filename:
        sys.stdout = open(filename, 'w')

    IP_PREFIX = '172.17.0.'

    print(num_devices)

    for i in range(num_devices):
        ip = f"{IP_PREFIX}{i}"
        flops = random.randint(*flops_range)
        memory = random.randint(*memory_range)
        print(f"{ip} {flops} {memory}")

    for i in range(num_devices):
        bandwidth = random.randint(*bandwidth_range)
        print(bandwidth)

    sys.stdout = old_stdout

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Process some integers.')
    # parser.add_argument('integers', metavar='N', type=int, nargs='+',
    #                     help='an integer for the accumulator')
    parser.add_argument('--num_devices', default="9", type=int, help='number of devices')
    parser.add_argument('--flops_range', default="300000000:1000000000",
                        help='flops range')
    parser.add_argument('--memory_range', default="1024:4096",
                        help='memory range (powers of 2)')
    parser.add_argument('--bandwidth_range', default="50:1000",
                        help='bandwidth range')

    args = parser.parse_args()

    parse_range = lambda arr: [int(val) for val in arr.split(":")]

    flops_range = parse_range(args.flops_range)
    memory_range = parse_range(args.memory_range)
    bandwidth_range = parse_range(args.bandwidth_range)

    write_graph(args.num_devices, flops_range, memory_range, bandwidth_range)